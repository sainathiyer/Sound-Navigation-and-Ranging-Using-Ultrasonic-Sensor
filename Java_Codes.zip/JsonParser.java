package com.ford.day1;

public class JsonParser extends Parser{

	@Override
	public void parse(String fileType) {
		// TODO Auto-generated method stub
		System.out.println("Parsed "+fileType+" Data");
	}
	
	

}
