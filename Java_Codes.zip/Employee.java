package com.ford.day1;

public class Employee {

	private String empId;
	private String empName;
	private String empAddress;
	private float empSalary;
	
	public Employee() {
		super();
	}

	public Employee(String empId, String empName, String empAddress, float empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAddress = empAddress;
		this.empSalary = empSalary;
	}
	
	public void displayEmpDetails() {
		System.out.println("The Employee Details are ");
		System.out.println("The Employee ID is "+empId);
		System.out.println("The Employee Name is "+empName);
		System.out.println("The Employee Salary is "+empSalary);
		System.out.println("The Employee Address is "+empAddress);
		
	}
	
	

}
