package com.ford.day1;

import java.util.Scanner;

public class BookShelf extends Furniture {
	Scanner sc = new Scanner(System.in);
	private int noOfShelves;

	public BookShelf() {
		super();
	}

	public BookShelf(int noOfShelves,int length,int height,int width) {
		super(length,width,height); //constructor overriding
		this.noOfShelves = noOfShelves;
	}
	
	public void acceptBookShelfDetails()
	{
		System.out.println("Enter the book shelf details");
		/*System.out.println("Enter the length of the furniture");
		length = sc.nextInt();
		System.out.println("Enter the height of the furniture");
		height = sc.nextInt();
		System.out.println("Enter the width of the furniture");
		width = sc.nextInt();*/
		super.acceptFurnitureDetails();
		System.out.println("Enter the no of shelves");
		noOfShelves = sc.nextInt();
		
	}
	public void displayBookShelfDetails()
	{
		System.out.println("Book Shelf Details are");
		System.out.println("The Lenght is "+length+"\n"+"The Width is "+width+"\n"+"The Height is "+height+"\n"+"The No Of Shelves are "+noOfShelves);
		
	}
	

}
