package com.ford.day1;

import java.util.Scanner;


public class Furniture {
	protected int length;
	protected  int width;
	protected  int height;
	
	protected  Scanner sc = new Scanner(System.in);
	public Furniture() {
		super();
	}


	public Furniture(int length, int width, int height) {
		super();
		this.length = length;
		this.width = width;
		this.height = height;
	}
	public void acceptFurnitureDetails()
	{
		
		System.out.println(("Enter the Furniture Details"));
		System.out.println("Enter the length of the furniture");
		length = sc.nextInt();
		System.out.println("Enter the height of the furniture");
		height = sc.nextInt();
		System.out.println("Enter the width of the furniture");
		width = sc.nextInt();
		
	}
	
	public void displayFurnitureDetails()
	{
		System.out.println("Furniture Details are");
		System.out.println("The Lenght is "+length+"\n"+"The Width is "+width+"\n"+"The Height is "+height);
		
	}

}
