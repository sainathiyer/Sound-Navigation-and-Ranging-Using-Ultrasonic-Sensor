package com.ford.day1;

public class DerivedClass extends BaseClass{
	@Override
	public void display()
	{
		System.out.println("Dislaying Derived Class");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BaseClass bc = new BaseClass();
		DerivedClass dc = new DerivedClass();
		bc.display();
		dc.display();
		bc= new DerivedClass();
		bc.display();
		//dc = (DerivedClass) new BaseClass(); //Compile Time OK but Runtime ??
		
	}

}
