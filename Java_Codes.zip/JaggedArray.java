package com.ford.day1;

public class JaggedArray {
	int jarr[][] = new int[3][];
	public void populateJaggedArray()
	{
		jarr[0] = new int[4]; //0th row 4 columns
		jarr[1] = new int[3]; //1st row 3 columns
		jarr[2] = new int[5]; //2nd row 5 columns
		
		for(int i=0;i<4;i++)
		{
			jarr[0][i]=(i+1)*10;
			System.out.print(jarr[0][i]+" ");	
		}
		System.out.println();
		
		for(int j=0;j<3;j++)
		{
			jarr[1][j]=(j+1)*100;
			System.out.print(jarr[1][j]+" ");
		}
		System.out.println();
		
		for(int k=0;k<5;k++)
		{
			jarr[2][k]=(k+1)*1000;
			System.out.print(jarr[2][k]+" ");
		}
		System.out.println();
		
	}
	public static void main(String[] args)
	{
		JaggedArray ja = new JaggedArray();
		ja.populateJaggedArray();
		
	}

}
