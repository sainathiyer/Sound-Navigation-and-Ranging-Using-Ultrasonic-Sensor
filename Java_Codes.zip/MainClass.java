package com.ford.day1;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Implementer implementer = new Implementer();
		Parser parser = new JsonParser();
		implementer.callParser(parser, "JSON File");
		
		parser = new XmlParser();
		implementer.callParser(parser, "XML File");
		
		parser = new PdfParser();
		implementer.callParser(parser, "PDF File");
		
		
	}

}
