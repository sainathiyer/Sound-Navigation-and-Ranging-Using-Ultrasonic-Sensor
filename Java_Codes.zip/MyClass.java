package com.ford.day1;

public class MyClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer1 = new Customer();
		customer1.setCustomerId("C001");
		customer1.setCustomerName("Sainath");
		customer1.setCustomerAddress("Pune");
		customer1.setCustomerPhone("8446055531");
		customer1.setProductName("Amazon_Voucher");
		customer1.setQuantity(10);
		customer1.setPurchaseValue(1000.1f);
		
		System.out.println("Customer Details are");
		System.out.println("Customer is"+ customer1);
		Customer customer2 = new Customer("C002","Sainath_Iyer","Pune","8446055531","FlipKart",2,1000.0f);
		System.out.println(customer2);
		Customer customer3 = new Customer("C003","Sainathan","Pune","8446055531");
		System.out.println(customer3);
		System.out.println("Customer Details Through Getters");
		System.out.println("Customer ID is "+customer2.getCustomerId());
		System.out.println("Customer Name is "+customer2.getCustomerName());
		System.out.println("Customer Address is "+customer2.getCustomerAddress());
		System.out.println("Customer Phone No is "+customer2.getCustomerPhone());
		System.out.println("Product Name is "+customer2.getProductName());
		System.out.println("Quantity Purchased "+customer2.getQuantity());
		System.out.println("Purchase Value is "+customer2.getPurchaseValue());
	
		

	}

}
