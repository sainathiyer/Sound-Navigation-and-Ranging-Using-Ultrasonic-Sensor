package com.ford.day1;

public interface Biller {
	public void addBiller();

}
