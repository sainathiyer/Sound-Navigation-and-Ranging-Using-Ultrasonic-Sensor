package com.ford.day1;

public class DebitCard {
	public void checkBalance()
	{
		System.out.println("Balance Amount is: ");
	}

}
