package com.ford.day1;

public class VaragsSample {
	
	public void getData(int num1, int num2, String... args)
	{
		int sum = num1 + num2;
		System.out.println("The result is "+sum);
		System.out.println("The elements in Varags: ");
		for(int i=0;i<args.length;i++)
		{
			System.out.println(args[i]);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VaragsSample vs = new VaragsSample();
		vs.getData(100,200,"One","Two","Three");
		vs.getData(100,200,"One","Two","Three","Four","Five","Six");
		vs.getData(10,20,"One","Two","Three");
		//vs.getData();
	}

}
