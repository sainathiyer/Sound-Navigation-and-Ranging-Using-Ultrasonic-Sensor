package com.ford.day1;

public class Point {
	private int x,y;
	
	public Point() {
		super();
	}

	public Point(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	public void displayPoint()
	{
		System.out.println("The x coordinate is "+x+" The y coordinate is "+y);
		
	}

}
