package com.ford.day1;

public class Account {
	public void deposit()
	{
		System.out.println("Deposited the Cash");
	}
	public void withdraw()
	{
		System.out.println("Cash Withdrawn");
	}
	
}
