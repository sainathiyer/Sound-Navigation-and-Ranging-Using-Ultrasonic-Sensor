package com.ford.day1;

public class MyMainClass {

	public static void main(String[] args) {
		Employee employee = new Employee();
		employee.displayEmpDetails();
		System.out.println("\n");
		Employee employee2 = new Employee("EOO1","Sainath","Pune",40000.10f);
		employee2.displayEmpDetails();

	}

}
