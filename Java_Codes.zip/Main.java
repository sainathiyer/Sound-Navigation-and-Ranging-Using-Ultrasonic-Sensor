package com.ford.day1;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CreditCardAccount cca = new CreditCardAccount();
		cca.addBiller();
		cca.calcInterest();
		cca.calcPremium();
		cca.calcTaxOnInterest();
		cca.closeAccount();
		cca.createAccount();
		cca.deposit();
		
	}

}
