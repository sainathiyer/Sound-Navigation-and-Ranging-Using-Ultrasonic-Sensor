package com.ford.day1;

public class BaseClass {
	public void display()
	{
		System.out.println("Displaying Base Class");
	}

}
