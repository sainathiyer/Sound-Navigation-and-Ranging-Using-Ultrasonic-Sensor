package com.ford.day1;

public class SampleStringMethods {
	public void compareStrings()
	{
		String str1 = "Pune";
		String str2 = "Pune";
		System.out.println("str1.equals(str2): "+str1.equals(str2));
		System.out.println("str1==str2: "+str1==str2);
		System.out.println("----------------------------");
		String str3 = "Chennai";
		String str4 = "Banglore";
		System.out.println("str3.equals(str4): "+str3.equals(str4));
		System.out.println("str3==str4: "+str3==str4);
		System.out.println("----------------------------");

		str3 = str4;
		System.out.println("str3.equals(str4): "+str3.equals(str4));
		System.out.println("str3==str4: "+str3==str4);
		System.out.println("----------------------------");

		
		String str5 = new String("Coimbatore");
		String str6 = new String("Coimbatore");
		System.out.println("str5.equals(str6): "+str5.equals(str6));
		System.out.println("str5==str6: "+str5==str6);
		System.out.println("----------------------------");

		String str7 = new String("Coimbatore");
		String str8 = new String("Coimbatore");
		System.out.println("str7.equals(str8): "+str7.equals(str8));
		System.out.println("str7==str8: "+str7==str8);

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SampleStringMethods ssm = new SampleStringMethods();
		ssm.compareStrings();

	}

}
