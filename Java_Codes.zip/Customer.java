package com.ford.day1;

public class Customer {
	
	private String customerId;
	private String customerName;
	private String customerAddress;
	private String customerPhone;
	private String productName;
	private int quantity;
	private float purchaseValue;
	
	
	public Customer() {
		super();
	}


	public Customer(String customerId, String customerName, String customerAddress, String customerPhone,
			String productName, int quantity, float purchaseValue) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerPhone = customerPhone;
		this.productName = productName;
		this.quantity = quantity;
		this.purchaseValue = purchaseValue;
	}
	
	


	public Customer(String customerId, String customerName, String customerAddress, String customerPhone) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerPhone = customerPhone;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getCustomerAddress() {
		return customerAddress;
	}


	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}


	public String getCustomerPhone() {
		return customerPhone;
	}


	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public float getPurchaseValue() {
		return purchaseValue;
	}


	public void setPurchaseValue(float purchaseValue) {
		this.purchaseValue = purchaseValue;
	}


	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", customerPhone=" + customerPhone + ", productName=" + productName + ", quantity="
				+ quantity + ", purchaseValue=" + purchaseValue + "]";
	}
		
	
	
	

}
