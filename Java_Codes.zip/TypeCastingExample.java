package com.ford.day1;

public class TypeCastingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int value = 1300;
		byte num = (byte) value;
		System.out.println(num);

	}

}
