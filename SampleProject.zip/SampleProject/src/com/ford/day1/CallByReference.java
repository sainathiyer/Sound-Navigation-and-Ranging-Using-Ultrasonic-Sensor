package com.ford.day1;
class RefObject{
	int score;
	public RefObject(int score)
	{
		this.score=score;
	}
	
}
public class CallByReference {
	public void called(RefObject refobj)
	{
		refobj.score = refobj.score+5;
		System.out.println("Score in called function is "+refobj.score);
		
	}
	public void calling()
	{
		RefObject ro = new RefObject(85);
		System.out.println("The score before call is "+ro.score);
		called(ro);
		System.out.println("The score after call is "+ro.score);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CallByReference cbr = new CallByReference();
		cbr.calling();
		
	}

}
