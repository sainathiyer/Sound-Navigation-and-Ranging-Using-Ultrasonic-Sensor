package com.ford.day1;

public class ArraysSample {
	int arr[] = new int[10];
	int [][]arr2 = new int[4][5];
	public void populate1DArray()
	{
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=(i+1)*10;
		}
	}
	
	public void display1DArray()
	{
		for(int j=0;j<arr.length;j++)
		{
			System.out.println("Element is "+arr[j]);
		}
	}
	
	public void populate2DArray()
	{
		for(int i=0;i<4;i++)
		{
			for(int j=0;j<5;j++)
			{
				arr2[i][j] = (i+j)*10;
				System.out.print(" "+arr2[i][j]);
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args)
	{
		ArraysSample as = new ArraysSample();
		//as.populate1DArray();
		//as.display1DArray();
		as.populate2DArray();
	}
}
