package com.ford.day1;

public abstract class Parser {
	
	public abstract void parse(String fileType);
	

}
