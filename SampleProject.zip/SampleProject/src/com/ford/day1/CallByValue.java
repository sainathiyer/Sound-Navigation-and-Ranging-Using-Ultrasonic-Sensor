package com.ford.day1;

public class CallByValue {
	
	public void called(int score)
	{
		score+=5;
		System.out.println("The value of the score in called function is "+score);	
	}
	public void calling()
	{
		int score = 85;
		System.out.println("The value of score in calling function before the call is "+score);
		called(score);
		System.out.println("The value of the score after the call is "+score);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CallByValue cvv = new CallByValue();
		cvv.calling();

	}

}
