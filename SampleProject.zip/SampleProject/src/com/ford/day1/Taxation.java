package com.ford.day1;

public interface Taxation {
	public void calcTaxOnInterest();
	

}
