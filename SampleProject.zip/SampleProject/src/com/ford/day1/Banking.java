package com.ford.day1;

public interface Banking extends Insurance,Taxation {
	public void createAccount();
	public void closeAccount();
	public void calcInterest();
	
	
	
	
}
