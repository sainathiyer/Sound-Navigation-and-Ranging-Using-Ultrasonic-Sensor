package com.ford.day1;

public class MyPoint {
	
	public Point[] generatePoints()
	{
		Point[] points = new Point[10];
		for(int i=0;i<10;i++)
		{
			points[i] = new Point(i+10,i+20);
		}
		return points;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyPoint mp = new MyPoint();
		Point mypoints[];
		mypoints = mp.generatePoints();
		for(int i=0;i<mypoints.length;i++)
		{
			mypoints[i].displayPoint();
		}

	}
}
