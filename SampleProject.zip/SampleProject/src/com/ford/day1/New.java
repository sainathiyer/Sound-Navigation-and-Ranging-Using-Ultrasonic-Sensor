package com.ford.day1;

public class New {

}
