package com.ford.day1;

public interface Insurance {
	public void createPolicy();
	public void terminatePolicy();
	public void calcPremium();
	

}
