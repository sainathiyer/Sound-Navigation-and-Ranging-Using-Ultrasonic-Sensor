package com.ford.day1;

public class FurnitureShop {

	public static void main(String[] args) {
		BookShelf shelf1 = new BookShelf();
		//shelf1.acceptBookShelfDetails();
		//shelf1.displayBookShelfDetails();
		
		Furniture fur1 = new Furniture();
		//fur1.acceptFurnitureDetails();
		//fur1.displayFurnitureDetails();
		
		BookShelf shelf2 = new BookShelf(5,4,5,6);
		shelf2.displayBookShelfDetails();
		//Furniture fur2 = new Furniture();
		//fur2.displayFurnitureDetails();
		shelf2.displayFurnitureDetails();
	}

}
