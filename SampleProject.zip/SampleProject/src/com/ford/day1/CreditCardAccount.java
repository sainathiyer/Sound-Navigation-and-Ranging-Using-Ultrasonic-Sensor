package com.ford.day1;

public class CreditCardAccount extends Account implements Banking,Biller{

	@Override
	public void createPolicy() {
		// TODO Auto-generated method stub
		System.out.println("Policy Created");
		
	}

	@Override
	public void terminatePolicy() {
		// TODO Auto-generated method stub
		System.out.println("Policy Terminated");
		
	}

	@Override
	public void calcPremium() {
		// TODO Auto-generated method stub
		System.out.println("Premium Calculated...");
		
	}

	@Override
	public void calcTaxOnInterest() {
		// TODO Auto-generated method stub
		System.out.println("Interest on Tax Calculated...");
		
		
	}

	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Created..");
		
	}

	@Override
	public void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Closed...");
		
	}

	@Override
	public void calcInterest() {
		// TODO Auto-generated method stub
		System.out.println("Interest Calculated...");
		
	}

	@Override
	public void addBiller() {
		// TODO Auto-generated method stub
		System.out.println("Biller Added...");
	}
	

}
