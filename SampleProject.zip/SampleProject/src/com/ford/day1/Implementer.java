package com.ford.day1;

public class Implementer {
	
	public void callParser(Parser parser, String fileType)
	{
		parser.parse(fileType);
	}
	
}
