package com.ford.day1;

public class FunctionOverloading {
	int grossSalary;
	int netSalary;
	public void calculateSalary(int basic,int hra,int cca)
	{
		grossSalary = (basic+hra+cca);
		System.out.println("The Gross Salary w/0 allaowance is "+grossSalary);
		
	}

	public void calculateSalary(int basic,int hra,int cca,int allowance)
	{
		grossSalary = (basic+hra+cca+allowance);
		System.out.println("The Gross Salary with allaowance is "+grossSalary);
		
	}
	
	public void calculateSalary(int basic,int hra,int cca,int allowance,int deduction,String empName)
	{
		netSalary = (basic+hra+cca+allowance)-deduction;
		System.out.println("The Net Salary of the Employee "+empName+" is "+ netSalary);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FunctionOverloading fo = new FunctionOverloading();
		fo.calculateSalary(100, 200, 300);
		fo.calculateSalary(120, 10, 10, 10);
		fo.calculateSalary(1000, 2000, 3000, 10, 10, "Sainath");
		

	}

}
